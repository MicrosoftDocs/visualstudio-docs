﻿namespace StockAnalysis;

public interface IStockFeed
{
    int Value { get; set; }

    int GetSharePrice(string company);
}
