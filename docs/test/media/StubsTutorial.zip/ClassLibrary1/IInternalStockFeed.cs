﻿namespace StockAnalysis;

internal interface IInternalStockFeed
{
    int Value { get; set; }

    int GetSharePrice(string company);
}
