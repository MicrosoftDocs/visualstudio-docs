﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockAnalysis;

internal class InternalStockAnalyzer
{
    private IInternalStockFeed stockFeed;

    public InternalStockAnalyzer()
    {
    }

    internal InternalStockAnalyzer(IInternalStockFeed feed)
    {
        stockFeed = feed;
    }
    internal int GetContosoPrice()
    {
        return stockFeed.GetSharePrice("COOO");
    }
}
