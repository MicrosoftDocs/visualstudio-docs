﻿using HexFileReader;
using Microsoft.QualityTools.Testing.Fakes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            using (ShimsContext.Create())
            {
                // Arrange
                System.IO.Fakes.ShimFile.ReadAllLinesString = (s) => new string[] { "Hello", "World", "Shims" };

                // Act
                var target = new HexFile("this_file_doesnt_exist.txt");

                Assert.AreEqual(3, target.Records.Length);
            }
        }
    }
}
